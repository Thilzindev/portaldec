<?php
/**
 * adm_script/blacklist_actions.php
 * Incluído pelo painel_admin.php no bloco AJAX.
 */

// ── GARANTIR QUE A TABELA EXISTE ──────────────────────────────────────────────
$conexao->query("CREATE TABLE IF NOT EXISTS blacklist (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome          VARCHAR(200) NOT NULL,
    rgpm          VARCHAR(30)  NOT NULL,
    adicionado_em DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$cols = [
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS adicionado_em  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS discord         VARCHAR(80)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS ip_publico      VARCHAR(60)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_user_agent   TEXT         DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_idioma       VARCHAR(20)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_timezone     VARCHAR(80)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_resolucao    VARCHAR(20)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_plataforma   VARCHAR(60)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_canvas_hash  VARCHAR(64)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_webgl_hash   VARCHAR(64)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_audio_hash   VARCHAR(64)  DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS fp_fonts        TEXT         DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS motivo_tipo     ENUM('texto','pdf') NOT NULL DEFAULT 'texto'",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS motivo_texto    TEXT         DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS motivo_pdf      LONGBLOB     DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS motivo_pdf_nome VARCHAR(200) DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS tempo           ENUM('permanente','temporario') NOT NULL DEFAULT 'permanente'",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS expiracao       DATETIME     DEFAULT NULL",
    "ALTER TABLE blacklist ADD COLUMN IF NOT EXISTS adicionado_por  VARCHAR(200) DEFAULT NULL",
];
foreach ($cols as $sql) { $conexao->query($sql); }

// ── ÍNDICES: só cria se ainda não existir ────────────────────────────────────
function criarIndiceSeNaoExiste($conexao, $tabela, $nomeIndice, $coluna) {
    $res = $conexao->query("SHOW INDEX FROM `{$tabela}` WHERE Key_name = '{$nomeIndice}'");
    if ($res && $res->num_rows === 0) {
        $conexao->query("ALTER TABLE `{$tabela}` ADD INDEX `{$nomeIndice}` ({$coluna})");
    }
}
criarIndiceSeNaoExiste($conexao, 'blacklist', 'idx_rgpm',    'rgpm');
criarIndiceSeNaoExiste($conexao, 'blacklist', 'idx_discord', 'discord(40)');
criarIndiceSeNaoExiste($conexao, 'blacklist', 'idx_ip',      'ip_publico');

// ── HELPER: verifica se um registro está expirado ─────────────────────────────
function blacklistExpirado($row) {
    if ($row['tempo'] !== 'temporario' || empty($row['expiracao'])) {
        return false; // permanente nunca expira
    }
    try {
        $tz    = new DateTimeZone('America/Sao_Paulo');
        $agora = new DateTime('now', $tz);
        $exp   = new DateTime($row['expiracao'], $tz);
        return $exp <= $agora;
    } catch (Exception $e) {
        return false; // data invalida nao expira (mais seguro)
    }
}

// ── ADICIONAR NA BLACKLIST ────────────────────────────────────────────────────
if ($acao === 'adicionar_blacklist') {
    exigirNivel(NIVEL_ADM);

    $nome        = trim($_POST['nome']         ?? '');
    $rgpm        = trim($_POST['rgpm']         ?? '');
    $discord     = trim($_POST['discord']      ?? '') ?: null;
    $ip          = trim($_POST['ip']           ?? '') ?: null;
    $motivoTexto = trim($_POST['motivo_texto'] ?? '');
    $tempo       = trim($_POST['tempo']        ?? 'permanente');
    $adminNome   = $_SESSION['usuario'] ?? 'Desconhecido';

    $fpUserAgent  = trim($_POST['fp_user_agent']  ?? '') ?: null;
    $fpIdioma     = trim($_POST['fp_idioma']      ?? '') ?: null;
    $fpTimezone   = trim($_POST['fp_timezone']    ?? '') ?: null;
    $fpResolucao  = trim($_POST['fp_resolucao']   ?? '') ?: null;
    $fpPlataforma = trim($_POST['fp_plataforma']  ?? '') ?: null;
    $fpCanvas     = trim($_POST['fp_canvas_hash'] ?? '') ?: null;
    $fpWebgl      = trim($_POST['fp_webgl_hash']  ?? '') ?: null;
    $fpAudio      = trim($_POST['fp_audio_hash']  ?? '') ?: null;
    $fpFonts      = trim($_POST['fp_fonts']       ?? '') ?: null;

    if (!$nome || !$rgpm) {
        echo json_encode(['sucesso' => false, 'erro' => 'Nome e RGPM são obrigatórios']);
        exit;
    }
    if (!$motivoTexto) {
        echo json_encode(['sucesso' => false, 'erro' => 'Informe o motivo do banimento']);
        exit;
    }

    // ── Calcular expiração no servidor (evita problema de timezone do JS) ──
    $expVal = null;
    if ($tempo === 'temporario') {
        $duracao = trim($_POST['expiracao'] ?? '');
        // Aceita tanto duração nomeada quanto ISO/datetime direto
        if (in_array($duracao, ['1semana', '3semanas', '1mes'], true)) {
            $tz  = new DateTimeZone('America/Sao_Paulo');
            $now = new DateTime('now', $tz);
            if ($duracao === '1semana')  $now->modify('+7 days');
            if ($duracao === '3semanas') $now->modify('+21 days');
            if ($duracao === '1mes')     $now->modify('+1 month');
            $expVal = $now->format('Y-m-d H:i:s');
        } elseif (!empty($duracao)) {
            // Já veio como datetime string — normaliza
            $ts = strtotime($duracao);
            $expVal = $ts ? date('Y-m-d H:i:s', $ts) : null;
        }
        // Se ainda null, fallback para 7 dias
        if (!$expVal) {
            $expVal = date('Y-m-d H:i:s', strtotime('+7 days'));
        }
    }

    // Verifica se RGPM já está na blacklist
    $chk = $conexao->prepare("SELECT id FROM blacklist WHERE rgpm = ? LIMIT 1");
    if (!$chk) {
        echo json_encode(['sucesso' => false, 'erro' => 'Erro interno (chk): ' . $conexao->error]);
        exit;
    }
    $chk->bind_param("s", $rgpm);
    $chk->execute();
    if ($chk->get_result()->num_rows > 0) {
        echo json_encode(['sucesso' => false, 'erro' => "RGPM {$rgpm} já está na blacklist"]);
        $chk->close();
        exit;
    }
    $chk->close();

    // INSERT — 17 placeholders (motivo_tipo é literal 'texto' no SQL)
    $stmt = $conexao->prepare("INSERT INTO blacklist
        (nome, rgpm, discord, ip_publico,
         fp_user_agent, fp_idioma, fp_timezone, fp_resolucao, fp_plataforma,
         fp_canvas_hash, fp_webgl_hash, fp_audio_hash, fp_fonts,
         motivo_tipo, motivo_texto, tempo, expiracao, adicionado_por)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'texto',?,?,?,?)");

    if (!$stmt) {
        echo json_encode(['sucesso' => false, 'erro' => 'Erro interno (insert): ' . $conexao->error]);
        exit;
    }

    $stmt->bind_param(
        "sssssssssssssssss",
        $nome, $rgpm, $discord, $ip,
        $fpUserAgent, $fpIdioma, $fpTimezone, $fpResolucao, $fpPlataforma,
        $fpCanvas, $fpWebgl, $fpAudio, $fpFonts,
        $motivoTexto, $tempo, $expVal, $adminNome
    );

    if ($stmt->execute()) {
        echo json_encode(['sucesso' => true, 'id' => $conexao->insert_id, 'expiracao' => $expVal]);
    } else {
        echo json_encode(['sucesso' => false, 'erro' => 'Erro ao inserir: ' . $stmt->error]);
    }
    $stmt->close();
    exit;
}

// ── LISTAR BLACKLIST ──────────────────────────────────────────────────────────
if ($acao === 'listar_blacklist') {
    exigirNivel(NIVEL_ADM);

    $q = $conexao->query("
        SELECT id, nome, rgpm, discord, ip_publico,
               motivo_tipo, motivo_texto,
               tempo, expiracao, adicionado_por, adicionado_em
        FROM blacklist
        ORDER BY adicionado_em DESC
    ");

    if ($q === false) {
        echo json_encode(['sucesso' => false, 'erro' => 'Erro ao consultar blacklist: ' . $conexao->error]);
        exit;
    }

    $lista = [];
    while ($r = $q->fetch_assoc()) {
        $r['expirado'] = blacklistExpirado($r);
        $lista[] = $r;
    }

    echo json_encode(['sucesso' => true, 'blacklist' => $lista]);
    exit;
}

// ── REMOVER DA BLACKLIST ──────────────────────────────────────────────────────
if ($acao === 'remover_blacklist') {
    exigirNivel(NIVEL_ADM);

    $id = intval($_POST['id'] ?? 0);
    if (!$id) {
        echo json_encode(['sucesso' => false, 'erro' => 'ID invalido']);
        exit;
    }

    $stmt = $conexao->prepare("DELETE FROM blacklist WHERE id = ?");
    if (!$stmt) {
        echo json_encode(['sucesso' => false, 'erro' => 'Erro interno (delete): ' . $conexao->error]);
        exit;
    }
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['sucesso' => true]);
    } else {
        echo json_encode(['sucesso' => false, 'erro' => 'Erro ao remover: ' . $stmt->error]);
    }
    $stmt->close();
    exit;
}

// ── VERIFICAR BLACKLIST (cadastro) ────────────────────────────────────────────
if ($acao === 'verificar_blacklist_cadastro') {
    $rgpm     = trim($_POST['rgpm']            ?? '');
    $discord  = trim($_POST['discord']         ?? '');
    $ip       = trim($_POST['ip']              ?? '');
    $fpCanvas = trim($_POST['fp_canvas_hash']  ?? '');
    $fpWebgl  = trim($_POST['fp_webgl_hash']   ?? '');
    $fpAudio  = trim($_POST['fp_audio_hash']   ?? '');

    $bloqueado = false;
    $motivo    = '';
    $tempoStr  = '';

    if ($rgpm || $discord || $ip || $fpCanvas || $fpWebgl || $fpAudio) {
        $where  = [];
        $tipos  = '';
        $params = [];

        if ($rgpm)     { $where[] = 'rgpm = ?';                                      $tipos .= 's'; $params[] = $rgpm; }
        if ($discord)  { $where[] = 'discord = ?';                                   $tipos .= 's'; $params[] = $discord; }
        if ($ip)       { $where[] = 'ip_publico = ?';                                $tipos .= 's'; $params[] = $ip; }
        if ($fpCanvas) { $where[] = "(fp_canvas_hash = ? AND fp_canvas_hash != '')"; $tipos .= 's'; $params[] = $fpCanvas; }
        if ($fpWebgl)  { $where[] = "(fp_webgl_hash  = ? AND fp_webgl_hash  != '')"; $tipos .= 's'; $params[] = $fpWebgl; }
        if ($fpAudio)  { $where[] = "(fp_audio_hash  = ? AND fp_audio_hash  != '')"; $tipos .= 's'; $params[] = $fpAudio; }

        $sql  = "SELECT id, nome, motivo_tipo, motivo_texto, tempo, expiracao FROM blacklist WHERE (" . implode(' OR ', $where) . ") LIMIT 1";
        $stmt = $conexao->prepare($sql);
        if ($stmt && $tipos) {
            $stmt->bind_param($tipos, ...$params);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($row && !blacklistExpirado($row)) {
                $bloqueado = true;
                $motivo    = $row['motivo_texto'] ?: '[Consulte a administração]';
                $tempoStr  = $row['tempo'] === 'permanente'
                    ? 'Permanente'
                    : 'Temporário (até ' . date('d/m/Y H:i', strtotime($row['expiracao'])) . ')';
            }
        }
    }

    echo json_encode(['sucesso' => true, 'bloqueado' => $bloqueado, 'motivo' => $motivo, 'tempo' => $tempoStr]);
    exit;
}
<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: text/html; charset=utf-8');
mb_internal_encoding('UTF-8');

// ✅ NÃO chama session_start() aqui — a sessão já foi iniciada pelo painel_admin.php
// Se for chamado diretamente (sem sessão ativa), inicia
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

function responder($dados) {
    ob_end_clean();
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION["usuario"])) {
    responder(["sucesso" => false, "erro" => "Nao autorizado"]);
}

require_once __DIR__ . "/../conexao.php";

if (!isset($conexao) || $conexao->connect_error) {
    responder(["sucesso" => false, "erro" => "Falha na conexao: " . ($conexao->connect_error ?? 'sem objeto')]);
}

$conexao->set_charset("utf8mb4");

$curso = trim($_POST['curso'] ?? '');
$tag   = trim($_POST['tag']   ?? '');
$raw   = trim($_POST['ids']   ?? '');

if (!$curso || !$tag || !$raw) {
    responder(["sucesso" => false, "erro" => "Parametros incompletos. curso=$curso tag=$tag ids=$raw"]);
}

$ids = array_values(array_filter(array_map('trim', explode(',', $raw)), fn($v) => $v !== ''));

if (empty($ids)) {
    responder(["sucesso" => false, "erro" => "Nenhum ID fornecido"]);
}

$atualizados     = 0;
$nao_encontrados = [];

foreach ($ids as $id) {
    // Busca por RGPM ou Discord sem exigir meus_cursos preenchido
    // Aluno pode receber TEG mesmo sem pagamento aprovado
    $stmt = $conexao->prepare("SELECT id, tags FROM usuarios WHERE (rgpm = ? OR discord = ?) AND nivel = 3 LIMIT 1");
    $stmt->bind_param("ss", $id, $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $nao_encontrados[] = $id;
        continue;
    }

    $user   = $result->fetch_assoc();
    $userId = intval($user['id']);

    $tagsAtuais = [];
    if (!empty($user['tags'])) {
        $decoded    = json_decode($user['tags'], true);
        $tagsAtuais = is_array($decoded)
            ? $decoded
            : array_values(array_filter(array_map('trim', explode(',', $user['tags']))));
    }

    if (!in_array($tag, $tagsAtuais)) {
        $tagsAtuais[] = $tag;
    }

    $novasTags = json_encode(array_values($tagsAtuais), JSON_UNESCAPED_UNICODE);

    $upd = $conexao->prepare("UPDATE usuarios SET tags = ? WHERE id = ?");
    $upd->bind_param("si", $novasTags, $userId);

    if ($upd->execute()) {
        $atualizados++;
    } else {
        $nao_encontrados[] = $id;
    }
}

responder([
    "sucesso"               => true,
    "atualizados"           => $atualizados,
    "nao_encontrados"       => count($nao_encontrados),
    "lista_nao_encontrados" => $nao_encontrados
    
]);
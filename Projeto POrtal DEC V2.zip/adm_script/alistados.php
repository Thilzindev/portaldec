<?php
require __DIR__ . '/../conexao.php';
mb_internal_encoding('UTF-8');

/* VALORES PADRÃO */
$cfs  = 0;
$cfo  = 0;
$cfsd = 0;

/* CONSULTA — usando OOP igual ao resto do projeto */
$sql = "SELECT meus_cursos, COUNT(*) AS total 
        FROM usuarios 
        WHERE meus_cursos IN ('CFS','CFO','CFSD') 
        GROUP BY meus_cursos";

$resultado = $conexao->query($sql);

/* PROCESSAR RESULTADOS */
if ($resultado) {
    while ($row = $resultado->fetch_assoc()) {
        if ($row['meus_cursos'] === 'CFS')  $cfs  = $row['total'];
        if ($row['meus_cursos'] === 'CFO')  $cfo  = $row['total'];
        if ($row['meus_cursos'] === 'CFSD') $cfsd = $row['total'];
    }
}